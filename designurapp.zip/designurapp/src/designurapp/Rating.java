package designurapp;
import java.util.*;
public class Rating {
   static void ratenumberstatic(){

 Scanner input= new Scanner(System.in);
     double ratingapp=5;
      System.out.println("Please rate our app (Enter from 1 to 5 only):");
     double enternumber = input.nextDouble();
     if (enternumber<=5){
           System.out.println("Thank You For Your Rating");
     }
    else{
       
     do {
          System.out.println("The number is invalid, please try again: ");
          enternumber = input.nextDouble();
         
     } while (enternumber>5 ||enternumber<=0); 
      System.out.println("Thank You For Your Rating");
   }
   }
  public static void main(String[] args){
  
ratenumberstatic();
}
}
  
