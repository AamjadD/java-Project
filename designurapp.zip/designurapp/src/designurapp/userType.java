/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package designurapp;
public class userType {
       private String email, password, username,birthdata,number,city;

 public String getEmail() {
        return email;
    }

    public String getBirthdata() {
        return birthdata;
    }

    public String getNumber() {
        return number;
    }

    public String getCity() {
        return city;
    }
    public void newBirthdata (String birthdata) {
        this.birthdata = birthdata;
    }
    public void newCity(String city) {
        this.city = city;
    }
    public void newNumber (String number) {
        this.number= number;
    }
    public void newEmail (String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }
       public void newPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }
      public void newUsername (String username) {
        this.username = username;
    }



    public userType(String email, String password, String username, String city,String number,String birthdata){
        this.email = email;
        this.password = password;
        this.username = username;
        this.number = number;
        this.city = city;
        this.birthdata=birthdata;
          }
    
}

