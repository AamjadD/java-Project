/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package designurapp;
import java.util.ArrayList;
import java.util.Scanner;
public class Signup {
        
    String email, password, username,city,number,year,day,month;
    public void sys(){
       ArrayList<userType> users = new ArrayList<userType>(); // store and hold user input temporary
            Scanner input = new Scanner(System.in); // to obtain input from user
            System.out.println("========== SIGN UP PAGE ==========");
            System.out.println("Pick your choice:  ");
            System.out.println("1) User" + "\n" + "2) Designer");
            int choice = input.nextInt();
 ArrayList<userType> User = new ArrayList<userType>(); // store and hold user(User) input temporary
        ArrayList<userType> Designer = new ArrayList<userType>(); // store and hold user(Designer) input temporary

        switch (choice) {
        case 1:
            System.out.println("========== User Account ==========");
            System.out.print("username : ");
            username = input.next();
            System.out.print("email : "); // input userType information (email, password ...)
            email = input.next();
            System.out.print("password : ");
            password = input.next();

            System.out.print("birthdata (d m yyyy ): ");
            day = input.next();
            month = input.next();
            year  = input.next();
            System.out.print("number : ");
            number = input.next();
            System.out.print("city : ");
            city = input.next();

    User.add(new userType(email, password, username,city, number,year));
            break;

        case 2:
            System.out.println("========== Designer Account ==========");
            System.out.print("username : ");
            username = input.next();
            System.out.print("email : "); // input userType information (email, password ...)
            email = input.next();
            System.out.print("password : ");
            password = input.next();

            System.out.print("birthdata (d m yyyy ): ");
            day = input.next();
            month = input.next();
            year = input.next();
            System.out.print("number : ");
            number = input.next();
            System.out.print("city : ");
            city = input.next();
            Designer.add(new userType(email, password, username,city, number,year));
            break;

        default:
            System.out.println("Please pick your account type");}
        }}
