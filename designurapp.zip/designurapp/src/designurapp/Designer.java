package designurapp;
import java.util.*;
public class Designer {
    
Scanner input=new Scanner(System.in);
    private double x,x1,x2,x3, x4,y,z,b, f , p;
    
    static void entry(){
    Scanner input=new Scanner(System.in);
    String cardname , cardnumber,bool ;
System.out.println("Please Enter your card name:");
cardname= input.nextLine();
System.out.println("Please Enter your card number: ");
  cardnumber =input.next();
System.out.println( cardname + " is your card name and ("+cardnumber +") is your card number" + " is that correct? (Enter yes or no to update your data):");
 bool = input.next();
if (bool.equals("yes")||bool.equals("Yes")){
    System.out.println();
System.out.println("Then this is your card name and card number:\n "+ cardname+ "\n "+ cardnumber);}
else if (bool.equals("no")||bool.equals("No")){
 System.out.println("Which one you want to update *Enter a capital letter* \n A.Card name. \n B.Card number. \n C.Both");
 input.nextLine();
 String choice=input.nextLine();
 System.out.println();
 if (choice.equals("A")){
 System.out.println("Please Enter your updated card name:");
cardname= input.nextLine();
System.out.println();
System.out.println("Tnen this is your updated card name and card number: \n"+ cardname+ "\n"+ cardnumber);
 } else if (choice.equals("B")){
 System.out.println("Please Enter your updated card number: ");
  cardnumber =input.next();
  System.out.println();
 System.out.println("Tnen this is your card name and your updated card number\n "+ cardname+ " \n "+ cardnumber);
 
 } else if (choice.equals("C")){
 
 System.out.println("Please Enter your updated card name and card number:");
cardname=input.nextLine();
  cardnumber =input.next();
  System.out.println();
  System.out.println("Tnen this is your updated card name and updated card number: \n"+ cardname+ " \n "+ cardnumber);
 }     
    
}
System.out.println();
     System.out.print("Dear "+ cardname);
    
     
}

    public Designer(double x, double x1, double x2, double x3, double x4, double y, double z, double b, double f, double p) {
        this.x = x;
        this.x1 = x1;
        this.x2 = x2;
        this.x3 = x3;
        this.x4 = x4;
        this.y = y;
        this.z = z;
        this.b = b;
        this.f = f;
        this.p = p;
    }

    public double getX() {
        return x;
    }

    public double getX1() {
        return x1;
    }

    public double getX2() {
        return x2;
    }

    public double getX3() {
        return x3;
    }

    public double getX4() {
        return x4;
    }

    public double getY() {
        return y;
    }

    public double getZ() {
        return z;
    }

    public double getB() {
        return b;
    }

    public double getF() {
        return f;
    }

    public double getP() {
        return p;
    }
    

public void Setprices(){
Scanner input= new Scanner(System.in);
 System.out.println(" There will be a table to choose your work and inital prices.\n");
    System.out.println("-----------------------------------------------------------");
    System.out.println("|      Projects            |          cost                |");
    System.out.println("-----------------------------------------------------------");
    System.out.println("|     videos               |                              |");
    System.out.println("-----------------------------------------------------------");
    System.out.println("|     presentions          |                              |");
    System.out.println("-----------------------------------------------------------");
    System.out.println("|     mind maps            |                              |");
    System.out.println("-----------------------------------------------------------");
    System.out.println("|     infographics         |                              |");
    System.out.println("-----------------------------------------------------------");
    System.out.println("|     posters              |                              |");
    System.out.println("-----------------------------------------------------------");
    System.out.println("|    all of the above      |                              |");
    System.out.println("-----------------------------------------------------------");
    System.out.println("\nInside this table put the prices for the things you will do.\n ");
    System.out.println("Now, will you post:\n");
    System.out.println("1. Videos only\n2. Presentions only\n3. Mind Maps only\n4. Infographics only\n5. Posters only\n6. All of the above\n");
    System.out.println("Please enter a numbric value as in the menu");
    int numbric=input.nextInt();
    if (numbric==1){
    System.out.println("The price for a video:");
     x=input.nextDouble();
     
    
    System.out.println();
   
    System.out.println("------------------------------------------------------------");
    System.out.println("|      Projects            |          cost                 |");
    System.out.println("------------------------------------------------------------");
    System.out.println(  "|       videos             |  "+ x+" SR                    |");
    System.out.println("------------------------------------------------------------");
    System.out.println("|     presentions          |          -                    |");
    System.out.println("------------------------------------------------------------");
    System.out.println("|     mind maps            |          -                    |");
    System.out.println("------------------------------------------------------------");
    System.out.println("|     infographics         |          -                    |");
    System.out.println("------------------------------------------------------------");
    System.out.println("|     posters              |          -                    |");
    System.out.println("------------------------------------------------------------");
    System.out.println("|    all of the above      |          -                    |");
    System.out.println("------------------------------------------------------------");
    
    
    }
    if (numbric==2){
     System.out.println("The price for a prestion:");
    x1=input.nextDouble();
    System.out.println();
    System.out.println("-------------------------------------------------------------");
    System.out.println("|      Projects            |          cost                  |");
    System.out.println("-------------------------------------------------------------");
    System.out.println("|       videos             |          -                     |");
    System.out.println("-------------------------------------------------------------");
    System.out.println("  |     presentions          |"+x1+" SR                       |");
    System.out.println("-------------------------------------------------------------");
    System.out.println("|     mind maps            |          -                     |");
    System.out.println("-------------------------------------------------------------");
    System.out.println("|     infographics         |          -                     |");
    System.out.println("-------------------------------------------------------------");
    System.out.println("|     posters              |          -                     |");
    System.out.println("-------------------------------------------------------------");
    System.out.println("|    all of the above      |          -                     |");
    System.out.println("-------------------------------------------------------------");
    
    }
    if (numbric==3){
     System.out.println("The price for a mind map:");
     x2=input.nextDouble();
    System.out.println();
    
    System.out.println("--------------------------------------------------------------");
    System.out.println("|      Projects            |          cost                   |");
    System.out.println("--------------------------------------------------------------");
    System.out.println("|       videos             |          -                      |");
    System.out.println("--------------------------------------------------------------");
    System.out.println("|     presentions          |          -                      |");
    System.out.println("--------------------------------------------------------------");
    System.out.println(  "|     mind maps            |"+x2+" SR                        |");
    System.out.println("--------------------------------------------------------------");
    System.out.println("|     infographics         |          -                      |");
    System.out.println("--------------------------------------------------------------");
    System.out.println("|     posters              |          -                      |");
    System.out.println("--------------------------------------------------------------");
    System.out.println("|    all of the above      |          -                      |");
    System.out.println("--------------------------------------------------------------");
    
    
    }
    if(numbric==4){
    
     System.out.println("The price for a infographic:");
     x3=input.nextDouble();
    System.out.println();
    
    System.out.println("----------------------------------------------------------------");
    System.out.println("|      Projects            |          cost                     |");
    System.out.println("----------------------------------------------------------------");
    System.out.println("|       videos             |          -                        |");
    System.out.println("----------------------------------------------------------------");
    System.out.println("|     presentions          |          -                        |");
    System.out.println("----------------------------------------------------------------");
    System.out.println("|     mind maps            |          -                        |");
    System.out.println("----------------------------------------------------------------");
    System.out.println(  "|     infographics         |"+x3+" SR                          |");
    System.out.println("----------------------------------------------------------------");
    System.out.println("|     posters              |          -                        |");
    System.out.println("----------------------------------------------------------------");
    System.out.println("|    all of the above      |          -                        |");
    System.out.println("----------------------------------------------------------------");
   
    }
    if (numbric==5){
     System.out.println("The price for a poster:");
    x4=input.nextDouble();
    System.out.println();
    
    System.out.println("-----------------------------------------------------------------");
    System.out.println("|      Projects            |          cost                      |");
    System.out.println("-----------------------------------------------------------------");
    System.out.println("|       videos             |          -                         |");
    System.out.println("-----------------------------------------------------------------"); 
    System.out.println("|     presentions          |          -                         |");
    System.out.println("-----------------------------------------------------------------");
    System.out.println("|     mind maps            |          -                         |");
    System.out.println("-----------------------------------------------------------------");
    System.out.println("|     infographics         |          -                         |");
    System.out.println("-----------------------------------------------------------------");
    System.out.println(  "|     posters              |"+x4+" SR                           |");
    System.out.println("-----------------------------------------------------------------");
    System.out.println("|    all of the above      |          -                         |");
    System.out.println("-----------------------------------------------------------------");
  
    }
  
      if(numbric==6){
      System.out.println("The price for each one: ");
      System.out.println("for a video: ");
        y=input.nextDouble();
    System.out.println();
     System.out.println("for a presention: ");
      z=input.nextDouble();
    System.out.println();
     System.out.println("for a mind map: ");
       b=input.nextDouble();
    System.out.println();
     System.out.println("for a infographics: ");
      f=input.nextDouble();
    System.out.println();
    System.out.println("for a poster: ");
       p=input.nextDouble();
      System.out.println();
      
    System.out.println("---------------------------------------------------------------");
    System.out.println("|      Projects            |          cost                    |");
    System.out.println("---------------------------------------------------------------");
    System.out.println(  "|       videos             |  "+y+" SR                        |");
    System.out.println("---------------------------------------------------------------");
    System.out.println(  "|     presentions          |  "+z+" SR                        |");
    System.out.println("---------------------------------------------------------------");
    System.out.println(  "|     mind maps            |  "+b+" SR                        |");
    System.out.println("---------------------------------------------------------------");
    System.out.println(  "|     infographics         |  "+f+" SR                        |");
    System.out.println("---------------------------------------------------------------");
    System.out.println(  "|     posters              |  "+p+" SR                        |");
    System.out.println("---------------------------------------------------------------");
    
      } 
    System.out.println("your price table has been saved .");
   System.out.println();
}

    void addPost(String post) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void displayPosts() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void displayChatHistory() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    boolean authenticate(String password) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void addToChatHistory(String formattedMessage) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
