package designurapp;
import java.util.*;
public class PayingCustomer {
     private double videoprice,presentionprice,mindmapprice,infographicprice,posterprice,alloftheaboveprices1,alloftheaboveprices2,alloftheaboveprices3,alloftheaboveprices4,alloftheaboveprices5;
    Scanner input=new Scanner(System.in);
    void ChoosingCustomer(){
    System.out.println("\nwhat do you want to buy? ");
    System.out.println("\n1. Video\n2. presention\n3. mind map\n4. infographic\n5. poster\n6. all of the above\n   ");
    System.out.println("Please, Enter your choice (num only): ");
    int number=input.nextInt();
         switch (number) {
             case 1:
                 System.out.println("The cost of the video is: "+videoprice+" SR");
                 break;
             case 2:
                 System.out.println("The cost of the presention is: "+  presentionprice+ " SR");
                 break;
             case 3:
                 System.out.println("The cost of the mindmapprice is: "+mindmapprice+" SR");
                 break;
             case 4:
                 System.out.println("The cost pf the infographic is: "+ infographicprice+" SR");
                 break;
             case 5:
                 System.out.println("The cost pf the poster is: "+ posterprice+" SR");
                 break;
             case 6:
                 System.out.println("The cost of all of that is: "+(alloftheaboveprices1+alloftheaboveprices2+alloftheaboveprices3+alloftheaboveprices4+alloftheaboveprices5)+" SR\n");
                 break;
             default:
                 break;
         }
     System.out.println();
    entry();
    System.out.println(" ,please insert the cost: ");
    double price=input.nextDouble();
    
     System.out.println("\nThank for shopping with us :) ");
    }
   


    public PayingCustomer(double videoprice, double presentionprice, double mindmapprice, double infographicprice, double posterprice, double alloftheaboveprices1, double alloftheaboveprices2, double alloftheaboveprices3, double alloftheaboveprices4, double alloftheaboveprices5) {
        this.videoprice = videoprice;
        this.presentionprice = presentionprice;
        this.mindmapprice = mindmapprice;
        this.infographicprice = infographicprice;
        this.posterprice = posterprice;
        this.alloftheaboveprices1 = alloftheaboveprices1;
        this.alloftheaboveprices2 = alloftheaboveprices2;
        this.alloftheaboveprices3 = alloftheaboveprices3;
        this.alloftheaboveprices4 = alloftheaboveprices4;
        this.alloftheaboveprices5 = alloftheaboveprices5;  
}

    private void entry() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

    

    

