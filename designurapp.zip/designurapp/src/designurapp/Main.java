package designurapp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
public class Main {
    private static Map<String, Designer> designers;
    private static Map<String, Customer> customers;
    private static Community community;
    public static void main(String[] args) {
        Signup Signup=new Signup();
        Signin signin=new Signin();
        System.out.println("1) Sign up" + "\n" + "2) Sign in");
        Scanner input=new Scanner(System.in);
        int choice = input.nextInt();
        switch(choice){
            case 1:
            {
               Signup.sys();
                break;
            }
            
            case 2:
            {
                signin.Sys();
                break;
            }
        }  
   Customerpoints customer=new Customerpoints(90);
   System.out.println("The initial points that you have are:" + customer.getpoints()+"\n");
   System.out.println("your points will raise monthly about 20 points!\n");
    customer.incrasemonthly(20);
    System.out.println();
    customer.checkpoints();
    System.out.println();
        Designer sign = new Designer(0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        sign.entry();
        sign.Setprices();
        PayingCustomer customerr;
        customerr = new PayingCustomer(sign.getX(),sign.getX1(),sign.getX2(),sign.getX3(),sign.getX4(),sign.getY(),sign.getZ(),sign.getB(),sign.getF(),sign.getP());
        customerr.ChoosingCustomer();
       
    }
    private final String username;
    private final String password;
    private final ArrayList<Object> posts;
    private final ArrayList<Object> chatHistory;
    public Main(String username, String password) {
        this.username = username;
        this.password = password;
        this.posts = new ArrayList<>();
        this.chatHistory = new ArrayList<>();
    }

    public String getUsername() {
        return username;
    }

    public boolean authenticate(String password) {
        return this.password.equals(password);
    }

    public void addPost(String post) {
        posts.add(post);
        System.out.println("Post added successfully!");
    }

    public void displayPosts() {
        System.out.println("Posts by " + username + ":");
        for (Object post : posts) {
            System.out.println(post);
        }
    }

    public void addToChatHistory(String message) {
        chatHistory.add(message);
    }

    public void displayChatHistory() {
        System.out.println("Chat History with Customers:");
        for (Object message : chatHistory) {
            System.out.println(message);
        }
    }

    private static class designer {

        public designer() {
        }
    }

    private static class community {

        public community() {
        }
    }

class Customer {
    private final String username;
    private final String password;
    private final List<String> chatHistory;

    public Customer(String username, String password) {
        this.username = username;
        this.password = password;
        this.chatHistory = new ArrayList<>();
    }

    public String getUsername() {
        return username;
    }

    public boolean authenticate(String password) {
        return this.password.equals(password);
    }

    public void sendMessageToDesigner(Designer designer, String message) {
        String formattedMessage = username + ": " + message;
        designer.addToChatHistory(formattedMessage);
        System.out.println("Message sent successfully!");
    }

    public void displayChatHistory() {
        System.out.println("Chat History with Designer:");
        chatHistory.forEach((message) -> {
            System.out.println(message);
        });
    }
}

class Community {
    private final List<String> posts;

    public Community() {
        this.posts = new ArrayList<>();
    }

    public void addPost(String post) {
        posts.add(post);
        System.out.println("Post added successfully!");
    }

    public void displayPosts() {
        System.out.println("Community Posts:");
        for (String post : posts) {
            System.out.println(post);
        }
    }
    }
        Scanner scanner = new Scanner(System.in);
    public static void designerMenu(Scanner scanner, Designer designer) {
        while (true) {
            System.out.println("Designer Menu");
            System.out.println("1. Add Post");
            System.out.println("2. Display Posts");
            System.out.println("3. View Chat History");
            System.out.println("4. Logout");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter post content: ");
                    String post = scanner.nextLine();
                    designer.addPost(post);
                    break;
                case 2:
                    designer.displayPosts();
                    break;
                case 3:
                    designer.displayChatHistory();
                    break;
                case 4:
                    System.out.println("Logged out successfully!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    public static void customerMenu(Scanner scanner, Customer customer) {
        while (true) {
            System.out.println("Customer Menu");
            System.out.println("1. Send Message to Designer");
            System.out.println("2. View Chat History");
            System.out.println("3. View Community Posts");
            System.out.println("4. Logout");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter designer's username: ");
                    String designerUsername = scanner.nextLine();
                    if (designers.containsKey(designerUsername)) {
                        Designer designer = designers.get(designerUsername);
                        System.out.print("Enter your message: ");
                        String message = scanner.nextLine();
                        customer.sendMessageToDesigner(designer, message);
                    } else {
                        System.out.println("Designer not found. Please try again.");
                        }
                    break;
                case 2:
                    customer.displayChatHistory();
                    break;
                case 3:
                    community.displayPosts();
                    break;
                case 4:
                    System.out.println("Logged out successfully!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
