
package designurapp;
import java.util.Scanner;
public class Customerpoints {
 private  double points;

    public Customerpoints(double point) {
        this.points = point;
        
    }
    public double getpoints(){
    return points;
    }
    
    public void incrasemonthly(double increases){
    points=points+ increases;
    
    System.out.println("The points that you have with the increasement is :"+ points);
    }
   void  checkpoints(){
       Scanner input=new Scanner(System.in);
      System.out.println("do you want to use your points? \n1.yes\n2.not yet\n");
      int choices=input.nextInt();
      if (choices==1){
        System.out.println("how many you want to use? ");
        double points1=input.nextDouble();
   if (points>=100){
   points=points-points1;
    System.out.println("Thats your remaining points: "+ points + " because you used your points.");
   
   }
   
   }
      else {
      System.out.println("Okey, thats your points"+getpoints());
      
      }
   }
   
   
}
