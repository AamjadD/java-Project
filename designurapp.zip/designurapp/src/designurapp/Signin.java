
package designurapp;
import java.util.Scanner;
public class Signin extends Signup{
        Scanner scan = new Scanner(System.in);
    String pass;
    String user;
    //Enter your username and password from here
    public void Sys(){
        System.out.println("Enter Username: ");
        user = scan.nextLine();
        
        System.out.println("Enter Password: ");
        pass = scan.nextLine();
        
        validate();
    }
    //Username and password are verified from here
    public void validate(){
        Signup user=new Signup();
        Signup pass=new Signup();
         String checkuser=user.username;
         String checkpass=pass.password;
        if((user.username.equals(checkuser)) && pass.password.equals(checkpass)){
            System.out.println("Successfully Logged In");
        } else {
            System.out.println("Wrong user or password");
        }
    }
}
